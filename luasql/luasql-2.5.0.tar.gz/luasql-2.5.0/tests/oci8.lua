---------------------------------------------------------------------
-- Oracle specific tests and configurations.
---------------------------------------------------------------------

table.insert (CUR_METHODS, "numrows")
table.insert (EXTENSIONS, numrows)

DEFINITION_STRING_TYPE_NAME = "varchar(60)"
QUERYING_STRING_TYPE_NAME = "string"
